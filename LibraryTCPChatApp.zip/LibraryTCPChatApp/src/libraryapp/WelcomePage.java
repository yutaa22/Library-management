package libraryapp;

import javax.swing.*;
import java.awt.*;

public class WelcomePage extends JFrame {
    public WelcomePage() {
        setTitle("Welcome to Library App");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Create a central panel with GridBagLayout for more control
        JPanel centralPanel = new JPanel();
        centralPanel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10); // Padding around components

        // Welcome Label
        JLabel welcomeLabel = new JLabel("Library Management System", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(new Color(34, 139, 34));  // Dark Green Color
        gbc.gridx = 0;
        gbc.gridy = 0;
        centralPanel.add(welcomeLabel, gbc);

        // Buttons for Login and Register
        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.PLAIN, 14));
        loginButton.setBackground(new Color(34, 139, 34)); // Dark Green
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.addActionListener(e -> {
            new LoginPage().setVisible(true);
            dispose(); // Close welcome page
        });

        JButton registerButton = new JButton("Register");
        registerButton.setFont(new Font("Arial", Font.PLAIN, 14));
        registerButton.setBackground(new Color(60, 179, 113)); // Medium Sea Green
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        registerButton.addActionListener(e -> {
            new RegisterPage().setVisible(true);
            dispose(); // Close welcome page
        });

        // Add Buttons to Central Panel
        gbc.gridx = 0;
        gbc.gridy = 1;
        centralPanel.add(loginButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        centralPanel.add(registerButton, gbc);

        // Add centralPanel to JFrame
        add(centralPanel, BorderLayout.CENTER);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new WelcomePage());
    }
}
