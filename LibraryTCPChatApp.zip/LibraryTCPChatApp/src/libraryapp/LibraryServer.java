package libraryapp;

import java.io.*;
import java.net.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LibraryServer {
    public static void main(String[] args) throws IOException {
        ServerSocket server = new ServerSocket(5000);
        System.out.println("File-Based Server running on port 5000...");

        while (true) {
            Socket socket = server.accept();
            new Thread(() -> {
                try {
                    handleClient(socket);
                } catch (SQLException ex) {
                    Logger.getLogger(LibraryServer.class.getName()).log(Level.SEVERE, null, ex);
                }
            }).start();
        }
    }

    private static void handleClient(Socket socket) throws SQLException {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true)
        ) {
            String command = in.readLine();

            switch (command) {
    case "REGISTER":
        String regUser = in.readLine();
        String regPass = in.readLine();
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO users(username, password) VALUES (?, ?)")) {
            ps.setString(1, regUser);
            ps.setString(2, regPass);
            ps.executeUpdate();
            out.println("SUCCESS");
        } catch (SQLException e) {
            out.println("ERROR: " + e.getMessage());
        }
        break;

    case "LOGIN":
        String loginUser = in.readLine();
        String loginPass = in.readLine();
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE username=? AND password=?")) {
            ps.setString(1, loginUser);
            ps.setString(2, loginPass);
            ResultSet rs = ps.executeQuery();
            out.println(rs.next() ? "SUCCESS" : "FAIL");
        }
        break;

    case "VIEW":
        try (Connection conn = DBConnector.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM books")) {
            while (rs.next()) {
                out.println(rs.getInt("book_id") + " - " + rs.getString("title") + " by " + rs.getString("author") +
                        " | Available: " + rs.getBoolean("available"));
            }
            out.println("END");
        }
        break;

    case "BORROW":
        int bookId = Integer.parseInt(in.readLine());
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE books SET available=FALSE WHERE book_id=? AND available=TRUE")) {
            ps.setInt(1, bookId);
            int updated = ps.executeUpdate();
            out.println(updated > 0 ? "Borrowed Successfully" : "Book Unavailable");
        }
        break;

    default:
        out.println("INVALID");
        break;
}


        } catch (IOException e) {
        }
    }
}
