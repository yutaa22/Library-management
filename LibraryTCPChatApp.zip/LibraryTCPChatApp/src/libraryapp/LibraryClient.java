package libraryapp;

import javax.swing.*;
import java.awt.*;

public class LibraryClient {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame mainFrame = new JFrame("Library Client");
            mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            mainFrame.setSize(300, 200);
            mainFrame.setLayout(new GridLayout(3, 1, 10, 10));

            JLabel titleLabel = new JLabel("Welcome to Library System", SwingConstants.CENTER);
            titleLabel.setFont(new Font("Arial", Font.BOLD, 16));

            JButton loginButton = new JButton("Login");
            JButton registerButton = new JButton("Register");

            loginButton.addActionListener(e -> {
                new LoginPage().setVisible(true);
                mainFrame.dispose(); // Close the main frame
            });

            registerButton.addActionListener(e -> {
                new RegisterPage().setVisible(true);
                mainFrame.dispose(); // Close the main frame
            });

            mainFrame.add(titleLabel);
            mainFrame.add(loginButton);
            mainFrame.add(registerButton);

            mainFrame.setLocationRelativeTo(null); // Center the frame
            mainFrame.setVisible(true);
        });
    }
}
