package libraryapp;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DashboardPage extends JFrame {
    public DashboardPage() {
        setTitle("Dashboard");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JButton viewBtn = new JButton("View Books");
        JButton borrowBtn = new JButton("Borrow Book");
        JButton returnBtn = new JButton("Return Book");
        JButton addBtn = new JButton("Add Book");

        JPanel panel = new JPanel(new GridLayout(2, 2, 20, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 60, 40, 60));
        panel.add(viewBtn);
        panel.add(borrowBtn);
        panel.add(returnBtn);
        panel.add(addBtn);

        add(panel);

        viewBtn.addActionListener(e -> viewBooks());
        borrowBtn.addActionListener(e -> borrowBook());
        returnBtn.addActionListener(e -> returnBook());
        addBtn.addActionListener(e -> addBook());

        setVisible(true);
    }

    private void viewBooks() {
        try (Connection conn = DBConnector.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM books")) {

            StringBuilder sb = new StringBuilder();
            while (rs.next()) {
                sb.append(rs.getInt("book_id")).append(" - ")
                  .append(rs.getString("title")).append(" by ")
                  .append(rs.getString("author")).append(" | Available: ")
                  .append(rs.getBoolean("available"))
                  .append("\n");
            }
            JOptionPane.showMessageDialog(this, sb.toString());

        } catch (SQLException e) {
        }
    }

    private void borrowBook() {
        String id = JOptionPane.showInputDialog("Enter Book ID to Borrow:");
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE books SET available=FALSE WHERE book_id=? AND available=TRUE")) {

            ps.setInt(1, Integer.parseInt(id));
            int updated = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, updated > 0 ? "Book borrowed!" : "Book not available!");

        } catch (SQLException e) {
        }
    }

    private void returnBook() {
        String id = JOptionPane.showInputDialog("Enter Book ID to Return:");
        try (Connection conn = DBConnector.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE books SET available=TRUE WHERE book_id=?")) {

            ps.setInt(1, Integer.parseInt(id));
            int updated = ps.executeUpdate();
            JOptionPane.showMessageDialog(this, updated > 0 ? "Book returned!" : "Invalid Book ID!");

        } catch (SQLException e) {
        }
    }

    private void addBook() {
        JTextField titleField = new JTextField();
        JTextField authorField = new JTextField();
        JPanel input = new JPanel(new GridLayout(2, 2));
        input.add(new JLabel("Title"));
        input.add(titleField);
        input.add(new JLabel("Author"));
        input.add(authorField);

        int option = JOptionPane.showConfirmDialog(this, input, "Add Book", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try (Connection conn = DBConnector.getConnection();
                 PreparedStatement ps = conn.prepareStatement("INSERT INTO books(title, author, available) VALUES (?, ?, TRUE)")) {

                ps.setString(1, titleField.getText());
                ps.setString(2, authorField.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book added successfully!");

            } catch (SQLException e) {
            }
        }
    }
}
